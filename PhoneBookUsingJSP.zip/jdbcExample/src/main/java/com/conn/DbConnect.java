package com.conn;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnect {
	

	private static Connection conn;
	public static Connection getConn() {
		
		try {
			
Class.forName("oracle.jdbc.driver.OracleDriver");
conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","me","me");
return conn;
}
		catch(Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
}
