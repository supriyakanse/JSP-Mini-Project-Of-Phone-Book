package com.servlet;
import com.entity.*;
import javax.servlet.*;
import javax.servlet.http.HttpSession;
import com.conn.DbConnect;
import com.dao.*;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
@WebServlet("/addContact")
public class AddContact extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String phno=req.getParameter("phno");
		//String username=req.getParameter("username");
		
		//System.out.println(username+" "+name+" "+email+" "+phno+" ");
		Contact c=new Contact(name,email,phno);
		ContactDAO dao=new ContactDAO(DbConnect.getConn());
		HttpSession session=req.getSession();
		boolean f=dao.saveContact(c);
		if(f) {
			session.setAttribute("succMsg", "contact saved");
			resp.sendRedirect("addContact.jsp");
			
		}
		else {
			session.setAttribute("failedMsg", "contact not  saved");
			resp.sendRedirect("addContact.jsp");
			
		}
		
	}

	
}
