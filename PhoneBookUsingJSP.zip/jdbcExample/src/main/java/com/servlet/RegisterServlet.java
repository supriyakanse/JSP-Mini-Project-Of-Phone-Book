package com.servlet;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.conn.DbConnect;
import com.dao.UsersDAO;
import com.entity.Users;
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
	
	String name=request.getParameter("name");
	String email=request.getParameter("email");
	String password=request.getParameter("password");
	
	Users u=new Users(name,email,password);
	UsersDAO dao=new UsersDAO(DbConnect.getConn());
	boolean f=dao.usersRegister(u);
	
	HttpSession session=request.getSession();
	
	
	if(f) {
		session.setAttribute("sucssMsg", "user register successfully");
		response.sendRedirect("register.jsp");
		
		
		//System.out.println("user register successfully");
	}
	else {
		
		session.setAttribute("errorMsg", "user not register ");
		response.sendRedirect("register.jsp");
		//System.out.println("wrong");
		
	}
}
}
