package com.servlet;

import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.UsersDAO;
import com.entity.*;
import com.conn.DbConnect;
@WebServlet("/login")
public class LoginServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	String email=req.getParameter("email");
	String pass=req.getParameter("password");
	UsersDAO dao=new UsersDAO(DbConnect.getConn());
	Users u=dao.loginusers(email, pass);
	HttpSession session=req.getSession();
	if(u!=null) {
		session.setAttribute("user",u);
		resp.sendRedirect("index.jsp");
		//System.out.println("user is there"+u);
	}
	else {
		session.setAttribute("invalidMsg","Invalid email and password");
		resp.sendRedirect("login.jsp");
		//System.out.println("user is not there"+u);
	}
}
}