package com.dao;
import java.sql.*;

import com.entity.Users;
import com.conn.DbConnect;
public class UsersDAO {


private Connection conn;

	public UsersDAO(Connection conn) {
		super();
		this.conn=conn;		
	}
		
	public boolean usersRegister(Users u) {
		boolean f=false;
		
		try {
			
			String sql="insert into Users(name,email,password)values(?,?,?)";
			
			PreparedStatement ps=conn.prepareStatement(sql);
		
			ps.setString(1,u.getName());
			ps.setString(2,u.getEmail());
			ps.setString(3,u.getPassword());
			int i=ps.executeUpdate();
			if(i==1) {
				f=true;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return f;
		
	}
	
	
	public Users loginusers(String e,String p) {
		Users user=null;
		try {
			String sql="select *from Users where email=? and password=?";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,e);
			ps.setString(2,p);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				
				user=new Users();
				user.setName(rs.getString(1));
				user.setEmail(rs.getString(2));
				user.setPassword(rs.getString(3));
				
			}
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return user;
	}
	
}
