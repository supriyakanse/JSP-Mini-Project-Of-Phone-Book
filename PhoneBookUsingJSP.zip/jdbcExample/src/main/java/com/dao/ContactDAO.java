package com.dao;
import java.sql.*;
import java.util.*;
import com.entity.*;
public class ContactDAO {

	private Connection conn;
	public ContactDAO(Connection conn) {
		super();
		this.conn=conn;
	};
	public boolean saveContact(Contact c) {
		boolean f=false;
		try {
			
			String sql="insert into contact(name,email,phno)values(?,?,?)";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,c.getName());
			ps.setString(2,c.getEmail());
		    ps.setString(3, c.getPhno());
		    //ps.setString(4, c.getUserName());
			int i=ps.executeUpdate();
			if(i==1) {
				f=true;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	
	public List<Contact>getAllContact(String name){
		List<Contact> list=new ArrayList<Contact>();
		Contact c=null;
		try {
			String sql="select *from contact where name=?";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,name);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				
				c=new Contact();
				c.setName(rs.getString(1));
				c.setEmail(rs.getString(2));
				c.setPhno(rs.getString(3));
				list.add(c);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
		return list;
	}
	
	
}
